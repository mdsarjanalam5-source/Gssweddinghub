# G.S.S Wedding Hub — Android Studio + Firebase

यह Android Studio source project आपके दिए हुए HTML और `google-services.json` पर आधारित है। इसमें WebView में मौजूदा royal navy/gold UI, Firebase email/password Admin sign-in, Firestore bookings और Firebase Storage gallery upload जोड़ा गया है।

## Android Studio में चलाने के चरण
1. ZIP को Extract करें। Android Studio खोलें → **Open** → Extract किए गए `GSSWeddingHub` फ़ोल्डर को चुनें।
2. Gradle Sync पूरा होने दें। JDK 17 और Android SDK Platform 35 उपलब्ध रखें।
3. Firebase Console में `mdsarjanalam5@gmail.com` के लिए Email/Password Authentication enabled होना चाहिए। Password source code में नहीं रखा गया है; ऐप लॉगिन के समय पूछेगा।
4. Firebase Console → Firestore Database → Rules में `firebase/firestore.rules` का content publish करें।
5. Firebase Console → Storage → Rules में `firebase/storage.rules` का content publish करें।
6. सुनिश्चित करें कि Firebase Console में Android app package `Gs.wedding.hub` इसी project के साथ registered है और `app/google-services.json` उसी से है।
7. Run दबाकर device/emulator पर टेस्ट करें।

## जरूरी Web Firebase config नोट
HTML में Firebase Web SDK उपयोग किया गया है। यदि Firebase Auth/Storage को Web app registration की जरूरत बताते हुए error दे, Firebase Console → Project settings → Your apps → **Add app → Web** से Web app register करें और `app/src/main/assets/index.html` के `firebaseConfig` में Web app के `apiKey`, `authDomain`, `projectId`, `storageBucket`, `messagingSenderId`, और खासकर Web `appId` डालें। Android `google-services.json` अपने आप Web app ID नहीं देता।

## YAML workflow
`extract_zip.yml` को GitHub repository में `.github/workflows/extract_zip.yml` के रूप में रखें और ZIP को repository root में `GSS_Wedding_Hub_Firebase_Android_Studio.zip` नाम से commit करें। GitHub → Actions → **Extract ZIP and Build APK** → Run workflow चुनें। सफल build पर APK artifact डाउनलोड किया जा सकेगा।

## सुरक्षा
- Admin email को ऐप में allowlist किया गया है, लेकिन असली सुरक्षा Firebase Rules से आती है। दिए गए Rules को Firebase Console में publish करें।
- Booking submit करने के लिए public create permission है ताकि ग्राहक booking भेज सकें; bookings पढ़ना/बदलना केवल Admin को मिलता है।
- Gallery तस्वीरें सार्वजनिक रूप से दिखाई जाएँगी; upload/delete केवल Admin कर सकता है।
- पासवर्ड इस ZIP में नहीं है। साझा किए गए पासवर्ड को सुरक्षित रखने के लिए Firebase में बदलने पर विचार करें।

## सीमाएँ
यह Android Studio source ZIP है, तैयार APK नहीं। इस environment में Android SDK/Gradle build चलाकर device पर verify नहीं किया गया।
