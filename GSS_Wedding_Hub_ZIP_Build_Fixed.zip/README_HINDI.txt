GSS Wedding Hub - corrected ZIP-based APK build package

IMPORTANT:
GitHub Actions only runs workflow files committed in the repository at .github/workflows/.
A workflow stored only inside a ZIP file will not run by itself.

Steps:
1. In your GitHub repository, open .github/workflows/main.yml and replace its contents with the included main.yml.
2. Upload gss-wedding-hub-project.zip to the repository root (this package contains the project ZIP inside it).
3. Open Actions -> Build GSS Wedding Hub APK from ZIP -> Run workflow.
4. When the run succeeds, open the run and download the GSS-Wedding-Hub-debug-apk artifact.

This corrects the ZIP nesting / missing gradlew issue by using the installed Gradle command.
The APK build still needs to be run on GitHub Actions to confirm it succeeds.
