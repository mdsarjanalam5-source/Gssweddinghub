GSS Wedding Hub - ZIP based build package

Important:
GitHub does not run a workflow that is only inside a ZIP uploaded as a normal file.
For no-mobile-extract workflow:
1. In your existing GitHub repository, first add this workflow file at:
   .github/workflows/main.yml
   (GitHub web editor can create it; paste the included main.yml contents.)
2. Upload/commit gss-wedding-hub-project.zip to the repository root.
3. Open Actions -> Build GSS Wedding Hub APK from ZIP -> Run workflow.
4. Download the APK from the run's Artifacts section.

This package has not been built or tested on GitHub Actions yet.
